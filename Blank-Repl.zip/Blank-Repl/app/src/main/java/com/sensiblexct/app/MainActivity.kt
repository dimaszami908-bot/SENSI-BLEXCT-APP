package com.sensiblexct.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var btnOptimize: Button
    private lateinit var txtStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnOptimize = findViewById(R.id.btnOptimize)
        txtStatus = findViewById(R.id.txtStatus)

        btnOptimize.setOnClickListener {
            checkShizukuPermission()
        }
    }

    private fun checkShizukuPermission() {
        if (Shizuku.isPreV11()) {
            txtStatus.text = "Error: Versión de Shizuku no soportada"
            return
        }

        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            executeOptimization()
        } else {
            Shizuku.requestPermission(0)
        }
    }

    private fun executeOptimization() {
        txtStatus.text = "Estado: Optimización ejecutada con éxito"
    }
}